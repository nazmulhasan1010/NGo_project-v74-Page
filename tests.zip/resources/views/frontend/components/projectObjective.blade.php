<!-- project objective -->
<div class="project_summary  bg-dark-cu content-100 objective" id="capacityBuilding">
    <div class="heading">
        <span class="heading-1">Capacity</span>
        <span class="heading-2">Building</span>
    </div>
    <div class="row content-80">
        <div class="col-md-12 objectives">
            <ul>
                <li>
                    <i class="fa-solid fa-1">.</i>
                    <p>Safe Vegetable Production.</p>
                </li>
                <li>
                    <i class="fa-solid fa-2">.</i>
                    <p>Ecological farming.</p>
                </li>
                <li>

                    <i class="fa-solid fa-3"> .</i>
                    <p>Safe Vegetable marketing.</p>
                </li>
                <li>
                    <i class="fa-solid fa-4"> .</i>
                    <p>Environment improvement practice</p>
                </li>
            </ul>
        </div>
    </div>
</div> <!-- Project objective end -->
